import sys

from bokeh.command.bootstrap import main

main(sys.argv)