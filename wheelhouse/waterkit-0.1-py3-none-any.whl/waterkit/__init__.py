"""
Package for working with water data.
"""